<script setup lang="ts">
  import AppHeader from './layout/AppHeader.vue'
  import AppBody from './layout/AppBody.vue'
  import AppFooter from './layout/AppFooter.vue'
  import AppBackground from './layout/AppBackground.vue'
</script>

<template>
  <AppBackground/>
  <AppHeader/>
  <AppBody/>
  <AppFooter/>
</template>