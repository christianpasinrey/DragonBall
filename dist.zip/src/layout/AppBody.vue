<script setup lang="ts">
    import { RouterView } from 'vue-router';
</script>
<template>
     <div class="flex flex-col max-h-[90dvh] overflow-y-auto">
        <RouterView />
    </div>
</template>