<script setup lang="ts">
</script>
<template>
    <div class="absolute inset-0 z-[-1] overflow-hidden">
        <img
            class="w-full h-full object-cover opacity-40"
            src="@/assets/img/db-goku-transformations-2.webp"
            alt="Dragon Ball background"
        />
    </div>
</template>