<script setup lang="ts">
 
</script>

<template>
  <main class="relative overflow-hidden flex flex-wrap h-full w-full gap-4 md:gap-0 justify-start items-center content-center align-middle bg-transparent py-36 md:py-36 md:px-24">
    <!-- <div class="flex flex-col w-full md:w-1/3 px-8">
      <div class="box">
        Hola
      </div>
    </div>
    <div class="flex flex-col w-full md:w-2/3 px-8">
      <div class="box">
        Que tal
      </div>
    </div> -->
    <h1 class="text-4xl font-bold text-center text-slate-600">Dragon Ball Wiki</h1>
  </main>
</template>
<style scoped>
.box{
  @apply rounded-md p-4;
  background: linear-gradient(135deg, rgba(255,165,0,1), rgba(255,69,0,1));
  /* box-shadow: 0 10px 10px rgba(0,0,0,0.3); */
}

</style>